import React from 'react';

type ButtonProps = {
  value: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'accent';
  className?: string;
};

export function Button({ value, onClick, variant = 'primary', className = '' }: ButtonProps) {
  const baseStyles = 'text-xl font-medium rounded-2xl transition-all duration-200 hover:scale-95 active:scale-90';
  
  const variantStyles = {
    primary: 'bg-white/90 text-gray-800 hover:bg-white',
    secondary: 'bg-gray-500/20 text-gray-200 hover:bg-gray-500/30',
    accent: 'bg-violet-500 text-white hover:bg-violet-600',
  };

  return (
    <button
      onClick={onClick}
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
    >
      {value}
    </button>
  );
}