import React, { useState } from 'react';
import { Button } from './Button';
import { Display } from './Display';
import { evaluate } from '../../utils/calculator';

export function Calculator() {
  const [display, setDisplay] = useState('');
  const [expression, setExpression] = useState('');
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);

  const handleNumber = (num: string) => {
    if (shouldResetDisplay) {
      setDisplay(num);
      setShouldResetDisplay(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (operator: string) => {
    setShouldResetDisplay(true);
    setExpression(display + ' ' + operator);
  };

  const handleEqual = () => {
    try {
      const result = evaluate(expression + ' ' + display);
      setDisplay(result.toString());
      setExpression('');
    } catch (error) {
      setDisplay('Error');
    }
    setShouldResetDisplay(true);
  };

  const handleClear = () => {
    setDisplay('');
    setExpression('');
  };

  return (
    <div className="w-[350px] bg-gray-900/90 backdrop-blur-xl p-6 rounded-[2.5rem] shadow-2xl">
      <Display value={display} expression={expression} />
      
      <div className="grid grid-cols-4 gap-4">
        <Button value="C" onClick={handleClear} variant="secondary" />
        <Button value="±" onClick={() => setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display)} variant="secondary" />
        <Button value="%" onClick={() => setDisplay((parseFloat(display) / 100).toString())} variant="secondary" />
        <Button value="÷" onClick={() => handleOperator('/')} variant="accent" />

        <Button value="7" onClick={() => handleNumber('7')} />
        <Button value="8" onClick={() => handleNumber('8')} />
        <Button value="9" onClick={() => handleNumber('9')} />
        <Button value="×" onClick={() => handleOperator('*')} variant="accent" />

        <Button value="4" onClick={() => handleNumber('4')} />
        <Button value="5" onClick={() => handleNumber('5')} />
        <Button value="6" onClick={() => handleNumber('6')} />
        <Button value="-" onClick={() => handleOperator('-')} variant="accent" />

        <Button value="1" onClick={() => handleNumber('1')} />
        <Button value="2" onClick={() => handleNumber('2')} />
        <Button value="3" onClick={() => handleNumber('3')} />
        <Button value="+" onClick={() => handleOperator('+')} variant="accent" />

        <Button value="0" onClick={() => handleNumber('0')} className="col-span-2" />
        <Button value="." onClick={() => handleNumber('.')} />
        <Button value="=" onClick={handleEqual} variant="accent" />
      </div>
    </div>
  );
}