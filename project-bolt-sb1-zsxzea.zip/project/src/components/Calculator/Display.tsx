import React from 'react';

type DisplayProps = {
  value: string;
  expression: string;
};

export function Display({ value, expression }: DisplayProps) {
  return (
    <div className="bg-gray-800/50 rounded-3xl p-6 mb-4 text-right">
      <div className="text-gray-400 h-6 mb-1 text-lg">{expression || '\u00A0'}</div>
      <div className="text-white text-4xl font-light tracking-wider overflow-x-auto">
        {value || '0'}
      </div>
    </div>
  );
}