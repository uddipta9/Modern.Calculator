export function evaluate(expression: string): number {
  const parts = expression.trim().split(' ');
  if (parts.length !== 3) return 0;

  const [a, operator, b] = parts;
  const num1 = parseFloat(a);
  const num2 = parseFloat(b);

  switch (operator) {
    case '+':
      return num1 + num2;
    case '-':
      return num1 - num2;
    case '*':
      return num1 * num2;
    case '/':
      if (num2 === 0) throw new Error('Division by zero');
      return num1 / num2;
    default:
      throw new Error('Invalid operator');
  }
}